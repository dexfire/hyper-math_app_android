package work.mathwiki.activities;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;

import work.mathwiki.R;

/**
 * Created by Dexfire on 2018/8/4 0004.
 */

public class CollectionsActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.toast_info);
    }
}
