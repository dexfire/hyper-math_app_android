package work.mathwiki.views;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.widget.LinearLayout;

public class WelcomeView extends LinearLayout {
    public WelcomeView(Context context) {
        super(context);
    }

    public WelcomeView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }
}
