package work.mathwiki.core.network;

public class HttpResponseInfo {
    public int response_code;
    public String response_message;
}
