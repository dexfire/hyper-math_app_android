package work.mathwiki.core.model;

public interface AbstractMDEditor {


}
