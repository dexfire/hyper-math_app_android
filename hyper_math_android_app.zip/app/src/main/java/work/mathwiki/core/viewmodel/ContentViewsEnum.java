package work.mathwiki.core.viewmodel;

public enum ContentViewsEnum {
    home,
    content,
    toys,
}
