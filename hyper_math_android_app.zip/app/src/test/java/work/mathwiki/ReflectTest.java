package work.mathwiki;

public class ReflectTest {
    public static void main(String[] argv){

    }
}
